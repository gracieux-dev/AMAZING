"""
Visualiseur mlx - Rendu du labyrinthe avec menu interactif
Style inspiré d'Animal Crossing avec caractères spéciaux
"""

from typing import List, Tuple, TYPE_CHECKING
import os
if TYPE_CHECKING:
    from mazegen.generator import MazeGenerator

from mazegen.generator import NORTH, EAST, SOUTH, WEST

# pixels per cell and wall thickness used by both graphical renderers
_CELL = 24
_WALL = 3

MLX_THEMES = {
    'spring': {'wall': 0x225522, 'path': 0xFFC800, 'entry': 0x3CA0FF, 'exit': 0xFF4646, 'special': 0xB464DC, 'bg': 0xF0F8E6, 'panel': 0xC8E6B9, 'text': 0x1E3C1E},
    'summer': {'wall': 0x007882, 'path': 0xFFDC00, 'entry': 0x3CA0FF, 'exit': 0xFF4646, 'special': 0xB464DC, 'bg': 0xE1FAFF, 'panel': 0xAADCE6, 'text': 0x004650},
    'autumn': {'wall': 0x8C370A, 'path': 0xFFC800, 'entry': 0x3CA0FF, 'exit': 0xFF4646, 'special': 0xB464DC, 'bg': 0xFFF5E1, 'panel': 0xEBBE91, 'text': 0x642308},
    'winter': {'wall': 0x4B5F8C, 'path': 0x00D7FF, 'entry': 0x3CA0FF, 'exit': 0xFF4646, 'special': 0xB464DC, 'bg': 0xE1EBFF, 'panel': 0xB9CDF0, 'text': 0x233763},
}


def run_interactive(generator, entry: Tuple[int, int], exit_pos: Tuple[int, int], theme: str = "spring") -> None:
    """
    Lance l'interface interactive du visualiseur

    Args:
        generator: Générateur du labyrinthe
        entry: Position d'entrée
        exit_pos: Position de sortie
        theme: Thème visuel (spring, summer, autumn, winter)
    """
    try:
        visualizer: "MlxMazeVisualizer | MazeVisualizer" = MlxMazeVisualizer(generator, entry, exit_pos, theme)
    except ImportError:
        visualizer = MazeVisualizer(generator, entry, exit_pos, theme)
    visualizer.run()


# ---------------------------------------------------------------------------
# MLX graphical visualizer
# ---------------------------------------------------------------------------

class MlxMazeVisualizer:
    _PANEL_W = 220

    def __init__(self, generator, entry: Tuple[int, int], exit_pos: Tuple[int, int], theme: str = "spring") -> None:
        self.generator = generator
        self.entry = entry
        self.exit = exit_pos
        self.theme = theme
        self.show_solution = False
        self._solution_cache: set = set()
        self._solution_dirty = True

        from mlx import Mlx
        self._mlx = Mlx()
        self._ptr = self._mlx.mlx_init()
        self._init_window()

    def _init_window(self) -> None:
        h = len(self.generator.grid)
        w = len(self.generator.grid[0]) if h > 0 else 0
        self._maze_w = w * _CELL + _WALL
        self._maze_h = h * _CELL + _WALL
        self._win_w  = self._maze_w + self._PANEL_W
        self._win_h  = max(self._maze_h, 340)
        self._win = self._mlx.mlx_new_window(self._ptr, self._win_w, self._win_h, "A-Maze-ing")
        self._img = self._mlx.mlx_new_image(self._ptr, self._win_w, self._win_h)
        self._data, self._bpp, self._sl, _ = self._mlx.mlx_get_data_addr(self._img)

    def _c(self) -> dict:
        return MLX_THEMES.get(self.theme, MLX_THEMES['spring'])

    def _fill_rect(self, rx: int, ry: int, rw: int, rh: int, color: int) -> None:
        bpp = self._bpp // 8
        r = (color >> 16) & 0xFF
        g = (color >>  8) & 0xFF
        b =  color        & 0xFF
        row = bytes([b, g, r, 0xFF] * rw)
        for dy in range(rh):
            y = ry + dy
            if 0 <= y < self._win_h:
                start = y * self._sl + rx * bpp
                self._data[start:start + rw * bpp] = row

    def _fill_circle(self, cx: int, cy: int, radius: int, color: int) -> None:
        bpp = self._bpp // 8
        r = (color >> 16) & 0xFF
        g = (color >>  8) & 0xFF
        b =  color        & 0xFF
        pixel = bytes([b, g, r, 0xFF])
        r2 = radius * radius
        for dy in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                if dx * dx + dy * dy <= r2:
                    px, py = cx + dx, cy + dy
                    if 0 <= px < self._win_w and 0 <= py < self._win_h:
                        off = py * self._sl + px * bpp
                        self._data[off:off + bpp] = pixel

    def _get_solution_positions(self) -> set:
        if self._solution_dirty:
            from mazegen.solver import MazeSolver
            solver = MazeSolver(self.generator)
            directions = solver.solve(self.entry, self.exit)
            positions: set = set()
            if directions:
                x, y = self.entry
                positions.add((x, y))
                for d in directions:
                    if   d == 'N': y -= 1
                    elif d == 'S': y += 1
                    elif d == 'E': x += 1
                    elif d == 'W': x -= 1
                    positions.add((x, y))
            self._solution_cache = positions
            self._solution_dirty = False
        return self._solution_cache

    def _render(self) -> None:
        c    = self._c()
        grid = self.generator.grid
        gh   = len(grid)
        gw   = len(grid[0]) if gh > 0 else 0
        sol  = self._get_solution_positions() if self.show_solution else set()

        # background
        self._fill_rect(0, 0, self._win_w, self._win_h, c['bg'])
        # panel background
        self._fill_rect(self._maze_w, 0, self._PANEL_W, self._win_h, c['panel'])

        cw = _CELL - _WALL  # inner cell size

        for y in range(gh):
            for x in range(gw):
                cell = grid[y][x]
                px   = x * _CELL + _WALL
                py   = y * _CELL + _WALL
                pos  = (x, y)

                if pos == self.entry:
                    self._fill_rect(px, py, cw, cw, c['entry'])
                elif pos == self.exit:
                    self._fill_rect(px, py, cw, cw, c['exit'])
                elif cell == 15:
                    self._fill_rect(px, py, cw, cw, c['special'])

                if pos in sol and pos not in (self.entry, self.exit):
                    self._fill_circle(px + cw // 2, py + cw // 2, _CELL // 6, c['path'])

                if cell & NORTH:
                    self._fill_rect(px - _WALL, py - _WALL, _CELL, _WALL, c['wall'])
                if cell & WEST:
                    self._fill_rect(px - _WALL, py - _WALL, _WALL, _CELL, c['wall'])

        # outer border
        self._fill_rect(0, 0, self._maze_w, _WALL, c['wall'])
        self._fill_rect(0, 0, _WALL, self._maze_h, c['wall'])
        self._fill_rect(0, self._maze_h - _WALL, self._maze_w, _WALL, c['wall'])
        self._fill_rect(self._maze_w - _WALL, 0, _WALL, self._maze_h, c['wall'])
        # panel divider
        self._fill_rect(self._maze_w, 0, _WALL, self._win_h, c['wall'])

        self._mlx.mlx_put_image_to_window(self._ptr, self._win, self._img, 0, 0)

        # panel text via mlx_string_put
        tc = c['text']
        ox = self._maze_w + 14
        self._mlx.mlx_string_put(self._ptr, self._win, ox, 18,  tc, "A-Maze-ing")
        gh2 = len(self.generator.grid)
        gw2 = len(self.generator.grid[0]) if gh2 > 0 else 0
        self._mlx.mlx_string_put(self._ptr, self._win, ox, 46,  tc, f"Taille  : {gw2} x {gh2}")
        self._mlx.mlx_string_put(self._ptr, self._win, ox, 64,  tc, f"Theme   : {self.theme.capitalize()}")
        perfect = getattr(self.generator, 'perfect', True)
        self._mlx.mlx_string_put(self._ptr, self._win, ox, 82,  tc, f"Parfait : {'Oui' if perfect else 'Non'}")
        if self.show_solution:
            self._mlx.mlx_string_put(self._ptr, self._win, ox, 100, tc, f"Chemin  : {len(sol)} cellules")
        self._mlx.mlx_string_put(self._ptr, self._win, ox, 130, tc, "-- Controles --")
        for i, (key, desc) in enumerate([
            ("[R]",     "Regenerer"),
            ("[S]",     "Solution on/off"),
            ("[T]",     "Changer theme"),
            ("[Entree]","Sauver & quitter"),
            ("[Esc]",   "Quitter"),
        ]):
            y_pos = 152 + i * 18
            self._mlx.mlx_string_put(self._ptr, self._win, ox,      y_pos, tc, key)
            self._mlx.mlx_string_put(self._ptr, self._win, ox + 70, y_pos, tc, desc)

    def _on_key(self, key: int, _: object) -> None:
        if key == 65307:    # Escape
            self._mlx.mlx_loop_exit(self._ptr)

        elif key == 65293:  # Return
            from .output_writer import write_output
            write_output(self.generator, self.entry, self.exit, "maze.txt")
            self._mlx.mlx_loop_exit(self._ptr)

        elif key == 114:    # r
            self.generator.generate()
            self._solution_dirty = True
            self._render()

        elif key == 115:    # s
            self.show_solution = not self.show_solution
            self._render()

        elif key == 116:    # t
            themes = list(MLX_THEMES.keys())
            self.theme = themes[(themes.index(self.theme) + 1) % len(themes)]
            self._render()

    def run(self) -> None:
        self._render()
        self._mlx.mlx_key_hook(self._win, self._on_key, None)
        self._mlx.mlx_hook(self._win, 33, 0, lambda _: self._mlx.mlx_loop_exit(self._ptr), None)
        self._mlx.mlx_loop(self._ptr)
        self._mlx.mlx_destroy_image(self._ptr, self._img)
        self._mlx.mlx_destroy_window(self._ptr, self._win)
        self._mlx.mlx_release(self._ptr)
